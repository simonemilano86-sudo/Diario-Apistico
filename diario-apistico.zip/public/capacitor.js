// Spazio riservato a Capacitor
